﻿校园工程师 · Campus Engineer 0.3-public

完整解压本压缩包，运行 CampusEngineer.exe。请保留 Data 文件夹、UnityPlayer.dll 和其他运行文件。
Extract the complete folder and run CampusEngineer.exe. Keep all companion files together.

WASD / 鼠标：移动与观察。E：互动。Esc：暂停和设置。Tab：工程记录。R：提示。J：课间发现手账。
简中、繁中和 English 可在开始与暂停菜单切换。Esc 可切换固定视点点击模式。

推开教室门，拿取数据板，收集三种传感器证据，在控制终端完成三段规则挑战。
纸飞机、木琴、浇花、风铃和隐藏星星属于可选探索，不是学习主线的前置条件。

This is a Windows-first development prototype, not a finished Steam release.
Hints are offline presets; Python examples are illustrative, without arbitrary Python execution.
公开版保留原创环境和游戏逻辑，未包含 Asset Store 的可选装饰模型。与早期本地构建的个别道具有所不同。

源码、介绍与反馈：https://github.com/syt1126/campus-engineer
素材与使用范围见 ThirdPartyNotices/ 和 LICENSE.md。
